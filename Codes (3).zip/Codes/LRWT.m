close all
clc
clear all


%% reading values from excel sheet 1
filename = 'wavedata.xlsx';
sheet = 1;
fRange   = 'B3:B52';
aRange   = 'D3:D52';
phiRange = 'E3:E52';

g   = 9.81;
f   = xlsread(filename,sheet,fRange);
a   = xlsread(filename,sheet,aRange);
phi = xlsread(filename,sheet,phiRange);
omega = 2*pi*f;
k     = omega.^2./g;

%% reading values from excel sheet 2
filename = 'wavedata.xlsx';
sheet2 = 2;
etaRange  = 'C3:C503';
tRange    = 'B3:B503';

g   = 9.81;
eta_actual    = xlsread(filename,sheet2,etaRange);
time_actual   = xlsread(filename,sheet2,tRange);

%% reading values from excel sheet 3
filename3 = 'wavedata.xlsx';
sheet3 = 3;
uRange    = 'B5:B96647';
zRange    = 'C5:C96647';
uStRange  = 'E5:E1004';
zStRange  = 'F5:F1004';
u_2   = xlsread(filename3,sheet3,uRange);
z_2   = xlsread(filename3,sheet3,zRange);
u_St  = xlsread(filename3,sheet3,uStRange);
z_St  = xlsread(filename3,sheet3,zStRange);
%% Finding Hs and Tp
Snn = a.^2./(2*(omega(2)-omega(1)));
%plot(omega,Snn)
variance = (1/2)*sum(a.^2);
Hs = 4*sqrt(variance); %16.7485
wmax = sqrt(2*g/Hs); %1.0823
fmax = wmax/(2*pi); %0.17
%figure
%plot(f,a);
%xline(wmax/(2*pi));

[maxH, indH] = max(a)
wp = omega(indH)
Tp = 2*pi/wp;  %14.287
%% Finding eta

eta =@(t) sum(a.*cos(-omega.*t + phi));
tspan = -50:0.2:50;
eta_total = zeros(length(tspan),1);
for i = 1:length(tspan)
    t = tspan(i);
    eta_total(i) = eta(t);
end
figure
plot(tspan,eta_total,'-b');hold on;
plot(time_actual,eta_actual,'-r');
xlim([-2.8 10])
legend('$$\eta$$ calculated from LRWT [m]','$$\eta$$ measured [m]','interpreter','latex');
xlabel('Time [s]','interpreter','latex');
ylabel('Elevation [m]','interpreter','latex');
grid on;
maximum = max(eta_total);
%% Applying directionality for LRWT and Wheeler's
s = 15;
FVR = s/(1+s);
%% Finding velocity with and without wheeler stretching

u = @(z) sum(a.*omega.*exp(k.*z).*cos(phi));
zstar = @(z) z - 16.6420;
u_w = @(z) sum(a.*omega.*exp(k.*zstar(z)).*cos(phi));

zspan = -80:0.001:maximum;
u_total = zeros(length(zspan),1);
u_wheeler = zeros(length(zspan),1);
for i = 1: length(zspan)
    z = zspan(i);
    u_total(i) = FVR*u(z);
    u_wheeler(i) = FVR*u_w(z);
end

%% plotting
figure
plot(u_total,zspan); hold on;
plot(u_wheeler,zspan);
plot(u_2,z_2)
plot(u_St,z_St)
xlabel('u(z) [m/s]','interpreter','latex');
ylabel('z [m]','interpreter','latex');
yline(0,'--k','SWL','interpreter','latex');
legend('LRWT','Wheeler','Second Order','Stokes','interpreter','latex','Location','southeast');
grid on;
xlim([0 30])
ylim([-80 maximum])
umax_wheeler = max(u_wheeler)
umax_LRWT    = max(u_total)
