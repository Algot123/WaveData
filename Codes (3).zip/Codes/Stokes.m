close all
clc
clear all
%% reading values from excel sheet 2
filename = 'wavedata.xlsx';
sheet2 = 2;
etaRange  = 'C3:C503';
tRange    = 'B3:B503';

g   = 9.81;
eta_actual    = xlsread(filename,sheet2,etaRange);
time_actual   = xlsread(filename,sheet2,tRange);
%% Finding Stokes order
g = 9.81;
H = 28.44;  %25.8255
T = 12.44; %12.643 
d = 1000;
Order = H/(g*T^2);
if (Order>0.001)&&(Order<0.01)
    order = 2;
else 
    order = 5;  
end

[wp] = fStokesIn(d, T, H, order)
x=0;

%% Finding eta
tspan = linspace(-11,100,1000)
for i = 1:length(tspan)
    t = tspan(i)
    [eta, etaij, swl] = fStokesEta(x, t, wp)
    eta1(i) = eta;
end
plot(tspan,eta1); hold on;
plot(time_actual,eta_actual,'-k', 'linewidth', 1.5);
grid on;
xlim([-2.8 10])
legend('$$\eta$$ calculated from Stokes [m]','$$\eta$$ measured [m]','interpreter','latex');
xlabel('Time [s]','interpreter','latex');
ylabel('Elevation [m]','interpreter','latex');
[etamax,ind1] = max(eta1)
tspan(ind1)
Height = max(eta1)-min(eta1)

%% Finding velocity
zspan = linspace(-80,16.642,1000)
for i = 1:length(zspan)
    z = zspan(i)
    [u, w, ur, uij] = fStokesVel(x, z, t, wp)
    u1(i) = u;
end
vel = u1';
ele = zspan'
figure
 plot(u1,zspan); hold on;
xlabel('u(z) [m/s]','interpreter','latex');
ylabel('z [m]','interpreter','latex');
yline(0,'--k','SWL','interpreter','latex');
grid on;
xlim([0 10])
ylim([-80 16.642])
 