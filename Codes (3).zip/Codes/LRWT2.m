close all
clc
clear all

tic
%% reading values from excel sheet 1
filename = 'wavedata.xlsx';
sheet = 1;
fRange   = 'B3 :B19';
aRange   = 'D3:D19';
phiRange = 'E3:E19';

g    = 9.81;
f   = xlsread(filename,sheet,fRange);
a   = xlsread(filename,sheet,aRange);
phi = xlsread(filename,sheet,phiRange);
omega = 2*pi*f;
k     = omega.^2./g;

%% reading values from excel sheet 2
filename = 'wavedata.xlsx';
sheet2 = 2;
etaRange  = 'C3:C503';
tRange    = 'B3:B503';

g   = 9.81;
eta_actual    = xlsread(filename,sheet2,etaRange);
time_actual   = xlsread(filename,sheet2,tRange);

%% Finding eta

eta1 = @(t)  sum(a.*cos(-omega.*t + phi));
eta2cell = cell(length(omega)*length(omega),1);
counter=1;
for i = 1:length(omega)
    for j = 1:length(omega) 
        if i==j
            Dijminus = 0;
        else 
            Dijminus = 4*(sqrt(k(i))-sqrt(k(j))).^2.*(k(i).*k(j))./((sqrt(k(i))-sqrt(k(j))).^2-abs(k(i)-k(j))); 
        end
        eta2cell{counter} = @(t) (1/4).*a(i).*a(j).*(((Dijminus - 2.*k(i).*k(j))./sqrt(k(i).*k(j))+(k(i)+k(j)))...
                                  .*cos(-omega(i).*t + phi(i)  +omega(j).*t - phi(j)) + (k(i)+k(j)).*cos(-omega(i).*t + phi(i)...
                                   -omega(j).*t + phi(j)));
        counter = counter + 1;
    end
end
eta2 = @(t,eta2cell)sum(cellfun(@(f)f(t), eta2cell));

eta = @(t,eta2cell) eta1(t) + eta2(t,eta2cell);
tspan = -50:0.2:50;
eta_total = zeros(length(tspan),1);
for i = 1:length(tspan)
    t = tspan(i);
    eta_total(i) = eta(t,eta2cell);
    eta_LRWT(i)  = eta1(t); 
end
%% plot eta
figure
plot(tspan,eta_total,'-b');hold on;
plot(time_actual,eta_actual,'-r');
xlim([-2.8 10])
legend('$$\eta$$ calculated from Second Order Random Wave Theory [m]','$$\eta$$ measured [m]','interpreter','latex');
xlabel('Time [s]','interpreter','latex');
ylabel('Elevation [m]','interpreter','latex');
grid on;
[maximum ,index] = max(eta_total);
tmax = tspan(index);

%% Finding velocity 

u1 = @(z) sum(a.*omega.*exp(k.*z).*cos(phi));
u2cell = cell(length(omega)*length(omega),1);
counter=1;
for i = 1:length(omega)
    for j = 1:length(omega)
        
        if i==j
            Dijminus = 0;
            omega_diff = 1;
        else 
            Dijminus = 4*(sqrt(k(i))-sqrt(k(j))).^2.*(k(i).*k(j))./((sqrt(k(i))-sqrt(k(j))).^2-abs(k(i)-k(j))); 
            omega_diff = omega(i)-omega(j);
        end
        
        u2cell{counter} = @(z)a(i).*a(j).*g^2./(4.*omega(i).*omega(j)).*(k(i)-k(j)).*Dijminus./(omega_diff).*...
                              exp(abs(k(i)-k(j)).*z).*cos(phi(i) - phi(j));
                       
        counter = counter + 1;
    end
end
u2 = @(z,u2cell)sum(cellfun(@(f)f(z), u2cell));
u = @(z,u2cell) u1(z) + u2(z,u2cell);
zspan = -80:0.001:16.642;
ele = zspan';
u_total = zeros(length(zspan),1);
for i = 1:length(zspan)
    z = zspan(i);
    u_total(i) = u(z,u2cell);
end
%% plot velocity
figure
plot(u_total,zspan);hold on;
xlabel('u(z) [m/s]','interpreter','latex');
ylabel('z [m]','interpreter','latex');
yline(0,'--k','SWL','interpreter','latex');
grid on;
xlim([0 30])
ylim([-80 16.642])

time_elapsed = toc
        
        